package ilja615.iljatech.util;

import net.minecraft.inventory.CraftingInventory;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;

import javax.annotation.Nonnull;

public class CraftingInventoryWrapper extends CraftingInventory
{

    private final IItemHandlerModifiable inv;

    public CraftingInventoryWrapper(IItemHandlerModifiable handler) {
        super(null, 3, 3);
        this.inv = handler;
    }

    @Override
    public int func_70302_i_() {
        return inv.getSlots();
    }

    @Override
    public boolean func_191420_l() {
        for(int i = 0; i < inv.getSlots(); i++) {
            if (!inv.getStackInSlot(i).func_190926_b()) return false;
        }
        return true;
    }

    @Override
    public ItemStack func_70301_a(int index) {
        return inv.getStackInSlot(index);
    }

    @Override
    public ItemStack func_70304_b(int index) {
        ItemStack s = func_70301_a(index);
        if(s.func_190926_b()) return ItemStack.field_190927_a;
        func_70299_a(index, ItemStack.field_190927_a);
        return s;
    }

    @Override
    public ItemStack func_70298_a(int index, int count) {
        ItemStack stack = inv.getStackInSlot(index);
        return stack.func_190926_b() ? ItemStack.field_190927_a : stack.func_77979_a(count);
    }

    @Override
    public void func_70299_a(int index, @Nonnull ItemStack stack) {
        inv.setStackInSlot(index, stack);
    }

    @Override
    public void func_174888_l() {
        for(int i = 0; i < inv.getSlots(); i++) {
            inv.setStackInSlot(i, ItemStack.field_190927_a);
        }
    }
}
