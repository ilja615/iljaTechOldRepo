package ilja615.iljatech.particles;

import net.minecraft.client.particle.*;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particles.BasicParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nullable;

@OnlyIn(Dist.CLIENT)
public class SteamParticle extends SimpleAnimatedParticle
{
    protected SteamParticle(ClientWorld world, double x, double y, double z, double motionX, double motionY, double motionZ, IAnimatedSprite spriteWithAge)
    {
        super(world, x, y, z, spriteWithAge, (float) motionY);
        this.field_187129_i = motionX + (Math.random() * 2.0d - 1.0d) * 0.03d;
        this.field_187130_j = motionY + (Math.random() * 2.0d - 1.0d) * 0.03d;
        this.field_187131_k = motionZ + (Math.random() * 2.0d - 1.0d) * 0.03d;
        this.field_70544_f += 0.2f;
        this.field_70547_e = 32 + this.field_187136_p.nextInt(16);
        this.func_217566_b(spriteWithAge);
    }


    @Override
    public IParticleRenderType func_217558_b()
    {
        return IParticleRenderType.field_217603_c;
    }

    @Override
    public void func_189213_a()
    {
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        if (this.field_70546_d++ >= this.field_70547_e) {
            this.func_187112_i();
        } else {
            this.func_217566_b(this.field_217584_C);
            this.field_70544_f += 0.003f;
            this.func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements IParticleFactory<BasicParticleType> {
        private final IAnimatedSprite spriteSet;

        public Factory(IAnimatedSprite spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Nullable
        @Override
        public Particle func_199234_a(BasicParticleType typeIn, ClientWorld worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            SteamParticle steamParticle = new SteamParticle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed, this.spriteSet);
            steamParticle.func_70538_b(1.0f, 1.0f, 1.0f);
            return steamParticle;
        }
    }
}
