package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModItems;
import ilja615.iljatech.init.ModProperties;
import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.power.IMechanicalPowerAccepter;
import ilja615.iljatech.power.IMechanicalPowerSender;
import ilja615.iljatech.power.MechanicalPower;
import ilja615.iljatech.tileentities.BellowsTileEntity;
import ilja615.iljatech.tileentities.BurnerTileEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.core.Direction;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.core.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.server.ServerWorld;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Random;

import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class BellowsBlock extends Block
{
    public static final DirectionProperty FACING = DirectionalBlock.FACING;
    public static final IntegerProperty COMPRESSION = IntegerProperty.create("compression", 0, 2);

    public BellowsBlock(Properties properties)
    {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(COMPRESSION, 0));
    }

    @Override
    public boolean hasTileEntity(BlockState state)
    {
        return true;
    }

    @Nullable
    @Override
    public BlockEntity createTileEntity(BlockState state, BlockGetter world)
    {
        return ModTileEntityTypes.BELLOWS.get().create();
    }

    public BlockState getStateForPlacement(BlockPlaceContext context)
    {
        return this.defaultBlockState().setValue(FACING, context.getNearestLookingDirection().getOpposite());
    }

    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder)
    {
        builder.add(FACING, COMPRESSION);
    }

    @Override
    public void attack(BlockState state, Level worldIn, BlockPos pos, Player player)
    {
        if (player.swingingArm != null && player.getItemInHand(player.swingingArm).getItem() == ModItems.IRON_HAMMER.get())
        {
            activate(worldIn, pos);
        }
        super.attack(state, worldIn, pos, player);
    }

    @Override
    public void fallOn(Level worldIn, BlockPos pos, Entity entityIn, float fallDistance)
    {
        if (worldIn.getBlockState(pos).hasProperty(FACING) && worldIn.getBlockState(pos).getValue(FACING).getAxis() != Direction.Axis.Y)
        {
            activate(worldIn, pos);
        }

        super.fallOn(worldIn, pos, entityIn, fallDistance);
    }

    private static void activate(Level world, BlockPos pos)
    {
        BlockEntity tileEntity = world.getBlockEntity(pos);
        if (tileEntity instanceof BellowsTileEntity)
        {
            ((BellowsTileEntity)tileEntity).compress(world, pos);
        }
    }
}
