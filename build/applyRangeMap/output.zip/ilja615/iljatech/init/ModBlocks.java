package ilja615.iljatech.init;

import ilja615.iljatech.IljaTech;
import ilja615.iljatech.blocks.*;
import net.minecraft.block.Block;
import net.minecraft.block.*;
import net.minecraft.block.material.Material;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

import ilja615.iljatech.util.ModUtils;

public class ModBlocks
{
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, IljaTech.MOD_ID);

    public static final RegistryObject<Block> IRON_PLATE = BLOCKS.register("iron_plate", () -> new PlateBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150339_S)));
    public static final RegistryObject<Block> GOLD_PLATE = BLOCKS.register("gold_plate", () -> new PlateBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150340_R)));
    public static final RegistryObject<Block> ALUMINIUM_PLATE = BLOCKS.register("aluminium_plate", () -> new PlateBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150339_S)));
    public static final RegistryObject<Block> TIN_PLATE = BLOCKS.register("tin_plate", () -> new PlateBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150339_S)));

    public static final RegistryObject<Block> IRON_ROD = BLOCKS.register("iron_rod", () -> new RodBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150339_S)));

    public static final RegistryObject<Block> IRON_NAILS = BLOCKS.register("iron_nails", () -> new NailsBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150339_S)));

    public static final RegistryObject<Block> NAILED_OAK_PLANKS = BLOCKS.register("nailed_oak_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_196662_n)));
    public static final RegistryObject<Block> NAILED_SPRUCE_PLANKS = BLOCKS.register("nailed_spruce_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_196664_o)));
    public static final RegistryObject<Block> NAILED_BIRCH_PLANKS = BLOCKS.register("nailed_birch_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_196666_p)));
    public static final RegistryObject<Block> NAILED_JUNGLE_PLANKS = BLOCKS.register("nailed_jungle_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_196668_q)));
    public static final RegistryObject<Block> NAILED_DARK_OAK_PLANKS = BLOCKS.register("nailed_dark_oak_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_196672_s)));
    public static final RegistryObject<Block> NAILED_ACACIA_PLANKS = BLOCKS.register("nailed_acacia_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_196670_r)));
    public static final RegistryObject<Block> NAILED_CRIMSON_PLANKS = BLOCKS.register("nailed_crimson_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_235344_mC_)));
    public static final RegistryObject<Block> NAILED_WARPED_PLANKS = BLOCKS.register("nailed_warped_planks", () -> new Block(AbstractBlock.Properties.func_200950_a(Blocks.field_235345_mD_)));

    public static final RegistryObject<Block> CRAFTER_MACHINE = BLOCKS.register("crafter_machine", () -> new CrafterMachineBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f)));

    // Mechanical
    public static final RegistryObject<Block> GEARBOX = BLOCKS.register("gearbox", () -> new GearboxBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f)));
    public static final RegistryObject<Block> CRANK = BLOCKS.register("crank", () -> new CrankBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_226896_b_().func_200942_a()));
    public static final RegistryObject<Block> TURBINE = BLOCKS.register("turbine", () -> new TurbineBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f)));

    // Thermal
    public static final RegistryObject<Block> BURNER = BLOCKS.register("burner", () -> new BurnerBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_196584_bK).func_235838_a_(ModUtils.getLightValueLit(13))));
    public static final RegistryObject<Block> BELLOWS = BLOCKS.register("bellows", () -> new BellowsBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200948_a(2.0F, 3.0F).func_226896_b_()));
    public static final RegistryObject<Block> STOKED_FIRE = BLOCKS.register("stoked_fire", () -> new StokedFireBlock(AbstractBlock.Properties.func_200950_a(Blocks.field_150480_ab).func_226896_b_().func_200942_a()));
}