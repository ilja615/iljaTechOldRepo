package ilja615.iljatech.items;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import ilja615.iljatech.blocks.NailsBlock;
import ilja615.iljatech.init.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.material.Material;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.*;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Map;

import net.minecraft.item.Item.Properties;

public class IronHammerItem extends TieredItem
{
    private final float attackDamage;
    private final Multimap<Attribute, AttributeModifier> attributeModifiers;

    protected static final Map<Block, Block> BLOCK_NAILS_MAP = (new ImmutableMap.Builder<Block, Block>())
            .put(Blocks.field_196662_n, ModBlocks.NAILED_OAK_PLANKS.get())
            .put(Blocks.field_196664_o, ModBlocks.NAILED_SPRUCE_PLANKS.get())
            .put(Blocks.field_196666_p, ModBlocks.NAILED_BIRCH_PLANKS.get())
            .put(Blocks.field_196668_q, ModBlocks.NAILED_JUNGLE_PLANKS.get())
            .put(Blocks.field_196670_r, ModBlocks.NAILED_ACACIA_PLANKS.get())
            .put(Blocks.field_196672_s, ModBlocks.NAILED_DARK_OAK_PLANKS.get())
            .put(Blocks.field_235345_mD_, ModBlocks.NAILED_WARPED_PLANKS.get())
            .put(Blocks.field_235344_mC_, ModBlocks.NAILED_CRIMSON_PLANKS.get()).build();

    protected static final Map<Block, Block> BLOCK_CRACKING_MAP = (new ImmutableMap.Builder<Block, Block>())
            .put(Blocks.field_196696_di, Blocks.field_196700_dk)
            .put(Blocks.field_196653_dH, Blocks.field_235394_nH_)
            .put(Blocks.field_196688_de, Blocks.field_196692_dg)
            .put(Blocks.field_235411_nu_, Blocks.field_235412_nv_)
            .put(Blocks.field_150348_b, Blocks.field_150347_e)
            .put(Blocks.field_150347_e, Blocks.field_150351_n).build();

    public IronHammerItem(Properties properties)
    {
        super(ItemTier.IRON, properties);
        this.attackDamage = 5 + ItemTier.IRON.func_200929_c();
        ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(Attributes.field_233823_f_, new AttributeModifier(field_111210_e, "Weapon modifier", (double)this.attackDamage, AttributeModifier.Operation.ADDITION));
        builder.put(Attributes.field_233825_h_, new AttributeModifier(field_185050_h, "Weapon modifier", -3.8f, AttributeModifier.Operation.ADDITION));
        this.attributeModifiers = builder.build();
    }

    @Override
    public ActionResultType func_195939_a(ItemUseContext context)
    {
        World world = context.func_195991_k();
        BlockPos blockpos = context.func_195995_a();
        BlockState blockstate = world.func_180495_p(blockpos);
        if (blockstate.func_177230_c() instanceof NailsBlock && blockstate.func_235901_b_(NailsBlock.STAGE))
        {
            world.func_184133_a(context.func_195999_j(), blockpos, SoundEvents.field_219705_mM, SoundCategory.BLOCKS, 1.0F, 1.0F);
            int stage = blockstate.func_177229_b(NailsBlock.STAGE);
            if (stage < 3)
                world.func_175656_a(blockpos, blockstate.func_206870_a(NailsBlock.STAGE, stage + 1));
            else
            {
                Block block = BLOCK_NAILS_MAP.get(world.func_180495_p(blockpos.func_177972_a(blockstate.func_177229_b(BlockStateProperties.field_208155_H))).func_177230_c());
                if (block != null)
                {
                    world.func_175656_a(blockpos, Blocks.field_150350_a.func_176223_P());
                    world.func_175656_a(blockpos.func_177972_a(blockstate.func_177229_b(BlockStateProperties.field_208155_H)), block.func_176223_P());
                }
            }
            return ActionResultType.SUCCESS;
        } else {
            Block block = BLOCK_CRACKING_MAP.get(world.func_180495_p(blockpos).func_177230_c());
            if (block != null)
            {
                world.func_184133_a(context.func_195999_j(), blockpos, SoundEvents.field_187835_fT, SoundCategory.BLOCKS, 1.0F, 1.0F);
                world.func_175656_a(blockpos, block.func_176223_P());
                context.func_195999_j().func_184811_cZ().func_185145_a(this, 20);
                return ActionResultType.SUCCESS;
            }
        }

        return super.func_195939_a(context);
    }

    @Override
    public boolean func_77644_a(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.func_222118_a(1, attacker, (entity) -> {
            entity.func_213361_c(EquipmentSlotType.MAINHAND);
        });
        return true;
    }

    @Override
    public boolean func_179218_a(ItemStack stack, World worldIn, BlockState state, BlockPos pos, LivingEntity entityLiving) {
        if (state.func_185887_b(worldIn, pos) != 0.0F) {
            stack.func_222118_a(1, entityLiving, (entity) -> {
                entity.func_213361_c(EquipmentSlotType.MAINHAND);
            });
        }

        return true;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> func_111205_h(EquipmentSlotType equipmentSlot) {
        return equipmentSlot == EquipmentSlotType.MAINHAND ? this.attributeModifiers : super.func_111205_h(equipmentSlot);
    }

    @Override
    public float func_150893_a(ItemStack stack, BlockState state) {
        Material material = state.func_185904_a();
        return material != Material.field_151573_f && material != Material.field_151574_g && material != Material.field_151576_e ? super.func_150893_a(stack, state) : ItemTier.IRON.func_200928_b();
    }

    @Override
    public boolean func_150897_b(BlockState blockIn) {
        int i = this.func_200891_e().func_200925_d();
        if (blockIn.getHarvestTool() == net.minecraftforge.common.ToolType.PICKAXE) {
            return i >= blockIn.getHarvestLevel();
        }
        Material material = blockIn.func_185904_a();
        return material == Material.field_151576_e || material == Material.field_151573_f || material == Material.field_151574_g;
    }
}
