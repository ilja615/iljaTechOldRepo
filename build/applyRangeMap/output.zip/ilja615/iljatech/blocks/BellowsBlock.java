package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModItems;
import ilja615.iljatech.init.ModProperties;
import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.power.IMechanicalPowerAccepter;
import ilja615.iljatech.power.IMechanicalPowerSender;
import ilja615.iljatech.power.MechanicalPower;
import ilja615.iljatech.tileentities.BellowsTileEntity;
import ilja615.iljatech.tileentities.BurnerTileEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DirectionalBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Random;

import net.minecraft.block.AbstractBlock.Properties;

public class BellowsBlock extends Block
{
    public static final DirectionProperty FACING = DirectionalBlock.field_176387_N;
    public static final IntegerProperty COMPRESSION = IntegerProperty.func_177719_a("compression", 0, 2);

    public BellowsBlock(Properties properties)
    {
        super(properties);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(COMPRESSION, 0));
    }

    @Override
    public boolean hasTileEntity(BlockState state)
    {
        return true;
    }

    @Nullable
    @Override
    public TileEntity createTileEntity(BlockState state, IBlockReader world)
    {
        return ModTileEntityTypes.BELLOWS.get().func_200968_a();
    }

    public BlockState func_196258_a(BlockItemUseContext context)
    {
        return this.func_176223_P().func_206870_a(FACING, context.func_196010_d().func_176734_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(FACING, COMPRESSION);
    }

    @Override
    public void func_196270_a(BlockState state, World worldIn, BlockPos pos, PlayerEntity player)
    {
        if (player.field_184622_au != null && player.func_184586_b(player.field_184622_au).func_77973_b() == ModItems.IRON_HAMMER.get())
        {
            activate(worldIn, pos);
        }
        super.func_196270_a(state, worldIn, pos, player);
    }

    @Override
    public void func_180658_a(World worldIn, BlockPos pos, Entity entityIn, float fallDistance)
    {
        if (worldIn.func_180495_p(pos).func_235901_b_(FACING) && worldIn.func_180495_p(pos).func_177229_b(FACING).func_176740_k() != Direction.Axis.Y)
        {
            activate(worldIn, pos);
        }

        super.func_180658_a(worldIn, pos, entityIn, fallDistance);
    }

    private static void activate(World world, BlockPos pos)
    {
        TileEntity tileEntity = world.func_175625_s(pos);
        if (tileEntity instanceof BellowsTileEntity)
        {
            ((BellowsTileEntity)tileEntity).compress(world, pos);
        }
    }
}
