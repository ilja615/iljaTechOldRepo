package ilja615.iljatech.blocks;

import ilja615.iljatech.entity.AbstractGasEntity;
import ilja615.iljatech.init.ModProperties;
import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.power.IMechanicalPowerAccepter;
import ilja615.iljatech.power.IMechanicalPowerSender;
import ilja615.iljatech.power.MechanicalPower;
import ilja615.iljatech.tileentities.BellowsTileEntity;
import ilja615.iljatech.tileentities.TurbineTileEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DirectionalBlock;
import net.minecraft.entity.Entity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Random;

import net.minecraft.block.AbstractBlock.Properties;

public class TurbineBlock extends Block implements IMechanicalPowerSender
{
    public static final DirectionProperty FACING = DirectionalBlock.field_176387_N;
    protected static final VoxelShape UP_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D);
    protected static final VoxelShape DOWN_AABB = Block.func_208617_a(0.0D, 2.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape NORTH_AABB = Block.func_208617_a(0.0D, 0.0D, 2.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape SOUTH_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 14.0D);
    protected static final VoxelShape WEST_AABB = Block.func_208617_a(2.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape EAST_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 14.0D, 16.0D, 16.0D);

    public TurbineBlock(Properties properties)
    {
        super(properties);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.OFF));
    }

    public VoxelShape func_220071_b(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context)
    {
        switch ((Direction)state.func_177229_b(FACING))
        {
            case DOWN:
            default:
                return DOWN_AABB;
            case UP:
                return UP_AABB;
            case NORTH:
                return NORTH_AABB;
            case SOUTH:
                return SOUTH_AABB;
            case WEST:
                return WEST_AABB;
            case EAST:
                return EAST_AABB;
        }
    }

    public VoxelShape func_230335_e_(BlockState state, IBlockReader reader, BlockPos pos) {
        return VoxelShapes.func_197868_b();
    }

    public VoxelShape func_230322_a_(BlockState state, IBlockReader reader, BlockPos pos, ISelectionContext context) {
        return VoxelShapes.func_197868_b();
    }

    @Override
    public boolean hasTileEntity(BlockState state)
    {
        return true;
    }

    @Nullable
    @Override
    public TileEntity createTileEntity(BlockState state, IBlockReader world)
    {
        return ModTileEntityTypes.TURBINE.get().func_200968_a();
    }

    public BlockState func_196258_a(BlockItemUseContext context)
    {
        return this.func_176223_P().func_206870_a(FACING, context.func_196010_d().func_176734_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(ModProperties.MECHANICAL_POWER, FACING);
    }

    @Override
    public void func_196262_a(BlockState state, World world, BlockPos pos, Entity entity)
    {
        if (!world.func_201670_d() && entity instanceof AbstractGasEntity)
        {
            if (world.func_180495_p(pos).func_235901_b_(ModProperties.MECHANICAL_POWER))
            {
                entity.func_70106_y();
                TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity instanceof TurbineTileEntity)
                {
                    ((TurbineTileEntity)tileEntity).startSpinning(world, pos, 200);
                }
            }
        }
    }
}