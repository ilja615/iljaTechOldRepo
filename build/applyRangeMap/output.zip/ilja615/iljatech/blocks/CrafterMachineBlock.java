package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.tileentities.CrafterMachineTileEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.CraftingInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.container.Container;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.Property;
import net.minecraft.state.StateContainer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraftforge.fml.network.NetworkHooks;

import javax.annotation.Nullable;

import net.minecraft.block.AbstractBlock.Properties;

public class CrafterMachineBlock extends HorizontalBlock
{
    public static final DirectionProperty FACING = HorizontalBlock.field_185512_D;

    public CrafterMachineBlock(Properties properties)
    {
        super(properties);
        this.func_180632_j((BlockState)((BlockState)this.field_176227_L.func_177621_b()).func_206870_a(FACING, Direction.NORTH));
    }

    @Override
    public boolean hasTileEntity(BlockState state)
    {
        return true;
    }

    @Nullable
    @Override
    public TileEntity createTileEntity(BlockState state, IBlockReader world)
    {
        return ModTileEntityTypes.CRAFTER_MACHINE.get().func_200968_a();
    }

    @Override
    public ActionResultType func_225533_a_(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockRayTraceResult rayTraceResult)
    {
        TileEntity tileEntity = world.func_175625_s(pos);
        if (tileEntity instanceof CrafterMachineTileEntity)
        {
            if (!world.func_201670_d())
            {
                NetworkHooks.openGui((ServerPlayerEntity)player, (CrafterMachineTileEntity)tileEntity, pos);
            }
            return ActionResultType.SUCCESS;
        }
        return ActionResultType.FAIL;
    }

    @Override
    public void func_196243_a(BlockState state, World worldIn, BlockPos pos, BlockState newState, boolean isMoving)
    {
        if (state.func_177230_c() != newState.func_177230_c())
        {
            TileEntity tileEntity = worldIn.func_175625_s(pos);
            if (tileEntity instanceof CrafterMachineTileEntity)
            {
                InventoryHelper.func_219961_a(worldIn, pos, ((CrafterMachineTileEntity)tileEntity).getItems());
            }
        }
        super.func_196243_a(state, worldIn, pos, newState, isMoving);
    }

    @Override
    public boolean func_149740_M(BlockState blockState) {
        return true;
    }

    @Override
    public int func_180641_l(BlockState blockState, World worldIn, BlockPos pos)
    {
        int j = 0;
        TileEntity tileEntity = worldIn.func_175625_s(pos);
        if (tileEntity instanceof CrafterMachineTileEntity)
        {
            for (int i = 0; i < ((CrafterMachineTileEntity)tileEntity).chestContents.size(); i++)
            {
                if (((CrafterMachineTileEntity)tileEntity).chestContents.get(i) != ItemStack.field_190927_a) j++;
            }
        }
        return Math.min(j, 15);
    }

    @Override
    public void func_220069_a(BlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos, boolean isMoving)
    {
        if (worldIn.func_175640_z(pos))
        {
            TileEntity tileEntity = worldIn.func_175625_s(pos);
            if (tileEntity instanceof CrafterMachineTileEntity)
            {
                ((CrafterMachineTileEntity)tileEntity).craft();
            }
        }
    }

    public BlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return (BlockState)this.func_176223_P().func_206870_a(FACING, p_196258_1_.func_195992_f().func_176734_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) { p_206840_1_.func_206894_a(new Property[]{FACING}); }
}
