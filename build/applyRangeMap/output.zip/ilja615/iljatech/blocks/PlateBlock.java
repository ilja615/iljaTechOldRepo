package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.IWaterLoggable;
import net.minecraft.block.SixWayBlock;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.SlabType;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.Random;

import net.minecraft.block.AbstractBlock.Properties;

public class PlateBlock extends Block implements IWaterLoggable
{
    public static final BooleanProperty NORTH = BlockStateProperties.field_208151_D;
    public static final BooleanProperty EAST = BlockStateProperties.field_208152_E;
    public static final BooleanProperty SOUTH = BlockStateProperties.field_208153_F;
    public static final BooleanProperty WEST = BlockStateProperties.field_208154_G;
    public static final BooleanProperty UP = BlockStateProperties.field_208149_B;
    public static final BooleanProperty DOWN = BlockStateProperties.field_208150_C;

    public static final BooleanProperty WATERLOGGED = BlockStateProperties.field_208198_y;

    public static final Map<Direction, BooleanProperty> FACING_TO_PROPERTY_MAP = SixWayBlock.field_196491_B;

    protected static final VoxelShape UP_AABB = Block.func_208617_a(0.0D, 14.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape DOWN_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
    protected static final VoxelShape WEST_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 2.0D, 16.0D, 16.0D);
    protected static final VoxelShape EAST_AABB = Block.func_208617_a(14.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape NORTH_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 2.0D);
    protected static final VoxelShape SOUTH_AABB = Block.func_208617_a(0.0D, 0.0D, 14.0D, 16.0D, 16.0D, 16.0D);

    public PlateBlock(Properties p_i48440_1_)
    {
        super(p_i48440_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(UP, Boolean.valueOf(false)).func_206870_a(DOWN, Boolean.valueOf(false)).func_206870_a(NORTH, Boolean.valueOf(false)).func_206870_a(EAST, Boolean.valueOf(false)).func_206870_a(SOUTH, Boolean.valueOf(false)).func_206870_a(WEST, Boolean.valueOf(false)).func_206870_a(WATERLOGGED, Boolean.valueOf(false)));
    }

    public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
        VoxelShape voxelshape = VoxelShapes.func_197880_a();
        if (state.func_177229_b(UP)) {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, UP_AABB);
        }

        if (state.func_177229_b(DOWN)) {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, DOWN_AABB);
        }

        if (state.func_177229_b(NORTH)) {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, NORTH_AABB);
        }

        if (state.func_177229_b(EAST)) {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, EAST_AABB);
        }

        if (state.func_177229_b(SOUTH)) {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, SOUTH_AABB);
        }

        if (state.func_177229_b(WEST)) {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, WEST_AABB);
        }
        return voxelshape;
    }

    public static BooleanProperty getPropertyFor(Direction side) {
        return FACING_TO_PROPERTY_MAP.get(side);
    }

    @Nullable
    public BlockState func_196258_a(BlockItemUseContext context)
    {
        BlockPos pos = context.func_195995_a();
        BlockState blockState = context.func_195991_k().func_180495_p(pos);
        if (blockState.func_203425_a(this))
        {
            // For adding to a existing block
            if (context.func_196000_l().func_176740_k() == Direction.Axis.Y)
            {
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() > 0.875D)
                    return blockState.func_206870_a(EAST, true);
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() < 0.125D)
                    return blockState.func_206870_a(WEST, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() > 0.875D)
                    return blockState.func_206870_a(SOUTH, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() < 0.125D)
                    return blockState.func_206870_a(NORTH, true);
            }
            if (context.func_196000_l().func_176740_k() == Direction.Axis.X)
            {
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() > 0.875D)
                    return blockState.func_206870_a(UP, true);
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() < 0.125D)
                    return blockState.func_206870_a(DOWN, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() > 0.875D)
                    return blockState.func_206870_a(SOUTH, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() < 0.125D)
                    return blockState.func_206870_a(NORTH, true);
            }
            if (context.func_196000_l().func_176740_k() == Direction.Axis.Z)
            {
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() > 0.875D)
                    return blockState.func_206870_a(UP, true);
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() < 0.125D)
                    return blockState.func_206870_a(DOWN, true);
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() > 0.875D)
                    return blockState.func_206870_a(EAST, true);
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() < 0.125D)
                    return blockState.func_206870_a(WEST, true);
            }
            // Default:
            if (!blockState.func_177229_b(FACING_TO_PROPERTY_MAP.get(context.func_196000_l().func_176734_d())))
                return blockState.func_206870_a(FACING_TO_PROPERTY_MAP.get(context.func_196000_l().func_176734_d()), true);
            else
                return blockState;
        } else {
            // For placing a new block:
            if (context.func_196000_l().func_176740_k() == Direction.Axis.Y)
            {
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() > 0.875D)
                    return this.func_176223_P().func_206870_a(EAST, true);
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() < 0.125D)
                    return this.func_176223_P().func_206870_a(WEST, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() > 0.875D)
                    return this.func_176223_P().func_206870_a(SOUTH, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() < 0.125D)
                    return this.func_176223_P().func_206870_a(NORTH, true);
                return this.func_176223_P().func_206870_a(FACING_TO_PROPERTY_MAP.get(context.func_196000_l().func_176734_d()), true);
            }
            if (context.func_196000_l().func_176740_k() == Direction.Axis.X)
            {
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() > 0.875D)
                    return this.func_176223_P().func_206870_a(UP, true);
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() < 0.125D)
                    return this.func_176223_P().func_206870_a(DOWN, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() > 0.875D)
                    return this.func_176223_P().func_206870_a(SOUTH, true);
                if (context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() < 0.125D)
                    return this.func_176223_P().func_206870_a(NORTH, true);
                return this.func_176223_P().func_206870_a(FACING_TO_PROPERTY_MAP.get(context.func_196000_l().func_176734_d()), true);
            }
            if (context.func_196000_l().func_176740_k() == Direction.Axis.Z)
            {
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() > 0.875D)
                    return this.func_176223_P().func_206870_a(UP, true);
                if (context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() < 0.125D)
                    return this.func_176223_P().func_206870_a(DOWN, true);
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() > 0.875D)
                    return this.func_176223_P().func_206870_a(EAST, true);
                if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() < 0.125D)
                    return this.func_176223_P().func_206870_a(WEST, true);
                return this.func_176223_P().func_206870_a(FACING_TO_PROPERTY_MAP.get(context.func_196000_l().func_176734_d()), true);
            }
            return this.func_176223_P().func_206870_a(FACING_TO_PROPERTY_MAP.get(context.func_196000_l()), true);
        }
    }

    public boolean func_196253_a(BlockState blockState, BlockItemUseContext context)
    {
        if (context.func_195996_i().func_77973_b() == this.func_199767_j())
        {
            if (context.func_196000_l() == Direction.UP && context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() >= 1)
                return false;
            if (context.func_196000_l() == Direction.DOWN && context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() <= 0)
                return false;
            if (context.func_196000_l() == Direction.EAST && context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() >= 1)
                return false;
            if (context.func_196000_l() == Direction.WEST && context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() <= 0)
                return false;
            if (context.func_196000_l() == Direction.SOUTH && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() >= 1)
                return false;
            if (context.func_196000_l() == Direction.NORTH && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() <= 0)
                return false;
            return true;
        }
        return false;
    }

    // Watterlogging stuff

    @Override
    public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
        switch(p_196266_4_) {
            case LAND:
                return false;
            case WATER:
                return p_196266_2_.func_204610_c(p_196266_3_).func_206884_a(FluidTags.field_206959_a);
            case AIR:
                return false;
            default:
                return false;
        }
    }

    public FluidState func_204507_t(BlockState p_204507_1_) {
        return (Boolean)p_204507_1_.func_177229_b(WATERLOGGED) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
        return true;
    }

    public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
        if ((Boolean)p_196271_1_.func_177229_b(WATERLOGGED)) {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
        }

        return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
        builder.func_206894_a(UP, DOWN, NORTH, EAST, SOUTH, WEST, WATERLOGGED);
    }
}
