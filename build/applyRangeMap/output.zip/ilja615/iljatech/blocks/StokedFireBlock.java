package ilja615.iljatech.blocks;

import net.minecraft.block.*;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

import java.util.Map;
import java.util.Random;

public class StokedFireBlock extends AbstractFireBlock
{
    private static final Map<Direction, BooleanProperty> FACING_TO_PROPERTY_MAP = SixWayBlock.field_196491_B.entrySet().stream().filter((facingProperty) -> {
        return facingProperty.getKey() != Direction.DOWN;
    }).collect(Util.func_199749_a());
    public static final IntegerProperty AIR = IntegerProperty.func_177719_a("air", 0, 3);

    public StokedFireBlock(AbstractBlock.Properties properties) {
        super(properties, 3.0F);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(AIR, 3));
    }

    public void func_220082_b(BlockState state, World worldIn, BlockPos pos, BlockState oldState, boolean isMoving)
    {
        worldIn.func_205220_G_().func_205360_a(pos, this, 20);
    }

    @Override
    public void func_225534_a_(BlockState state, ServerWorld worldIn, BlockPos pos, Random rand)
    {
        super.func_225534_a_(state, worldIn, pos, rand);
        if (!state.func_235901_b_(AIR)) return;
        int air = state.func_177229_b(AIR);
        if (air == 0)
        {
            worldIn.func_175656_a(pos, Blocks.field_150480_ab.func_176223_P());
        } else {
            worldIn.func_175656_a(pos, state.func_206870_a(AIR, Math.max(0, air - 1)));
            worldIn.func_205220_G_().func_205360_a(pos, this, 20);
        }
    }

    @Override
    public BlockState func_196258_a(BlockItemUseContext context)
    {
        return this.func_176223_P();
    }

    /**
     * Update the provided state given the provided neighbor facing and neighbor state, returning a new state.
     * For example, fences make their connections to the passed in state if possible, and wet concrete powder immediately
     * returns its solidified counterpart.
     * Note that this method should ideally consider only the specific face passed in.
     */
    public BlockState func_196271_a(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos)
    {
        int amountAir = stateIn.func_177229_b(AIR);
        return this.func_196260_a(stateIn, worldIn, currentPos) ? this.func_176223_P().func_206870_a(AIR, amountAir) : Blocks.field_150350_a.func_176223_P();
    }

    public boolean func_196260_a(BlockState state, IWorldReader worldIn, BlockPos pos) {
        BlockPos blockpos = pos.func_177977_b();
        return worldIn.func_180495_p(blockpos).func_224755_d(worldIn, blockpos, Direction.UP);
    }

    protected boolean func_196446_i(BlockState state) {
        return true;
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(AIR);
    }
}
