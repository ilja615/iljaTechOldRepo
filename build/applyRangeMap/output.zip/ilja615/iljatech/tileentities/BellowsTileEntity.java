package ilja615.iljatech.tileentities;

import ilja615.iljatech.blocks.BellowsBlock;
import ilja615.iljatech.entity.AbstractGasEntity;
import ilja615.iljatech.init.ModBlocks;
import ilja615.iljatech.init.ModEntities;
import ilja615.iljatech.init.ModTileEntityTypes;
import net.minecraft.block.BlockState;
import net.minecraft.block.DirectionalBlock;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.tileentity.ITickableTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.Direction;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BellowsTileEntity extends TileEntity implements ITickableTileEntity
{
    public BellowsTileEntity(TileEntityType<?> tileEntityTypeIn) { super(tileEntityTypeIn); }
    public BellowsTileEntity() { this(ModTileEntityTypes.BELLOWS.get()); }
    private int compressTimer;

    @Override
    public void func_73660_a()
    {
        if (this.compressTimer > 0)
        {
            --this.compressTimer;
            BlockState oldState = this.field_145850_b.func_180495_p(field_174879_c);
            if (this.compressTimer == 15)
            {
                this.field_145850_b.func_175656_a(field_174879_c, oldState.func_206870_a(BellowsBlock.COMPRESSION, 2));
                Direction facing = field_145850_b.func_180495_p(field_174879_c).func_177229_b(DirectionalBlock.field_176387_N);
                double d0 = (facing == Direction.EAST ? 0.6d : 0.0d) + (facing == Direction.WEST ? -0.6d : 0.0d);
                double d1 = (facing == Direction.UP ? 0.6d : 0.0d) + (facing == Direction.DOWN ? -0.6d : 0.0d);
                double d2 = (facing == Direction.NORTH ? -0.6d : 0.0d) + (facing == Direction.SOUTH ? 0.6d : 0.0d);
                AbstractGasEntity gasEntity = ModEntities.AIR_CLOUD.get().func_200721_a(this.field_145850_b);
                gasEntity.func_70012_b(0.5d + (double)field_174879_c.func_177958_n() + d0, 0.5d + (double)field_174879_c.func_177956_o() + d1, 0.5d + (double)field_174879_c.func_177952_p() + d2, 0.0f, 0.0F);
                gasEntity.func_70016_h(d0 / 2.0d, d1 / 2.0d, d2 / 2.0d);
                this.field_145850_b.func_217376_c(gasEntity);
            }
            if (this.compressTimer == 10)
            {
                this.field_145850_b.func_175656_a(field_174879_c, oldState.func_206870_a(BellowsBlock.COMPRESSION, 1));
            }
            if (this.compressTimer == 0)
            {
                this.field_145850_b.func_175656_a(field_174879_c, oldState.func_206870_a(BellowsBlock.COMPRESSION, 0));
            }
        }
    }

    public void compress(World world, BlockPos pos)
    {
        BlockState oldState = world.func_180495_p(pos);
        if (oldState.func_177230_c() == ModBlocks.BELLOWS.get() && oldState.func_177229_b(BellowsBlock.COMPRESSION) == 0)
        {
            world.func_175656_a(pos, oldState.func_206870_a(BellowsBlock.COMPRESSION, 1));
            this.compressTimer = 20;
        }
    }

    @Override
    public CompoundNBT func_189515_b(CompoundNBT compound)
    {
        super.func_189515_b(compound);
        compound.func_74768_a("CompressTimer", this.compressTimer);
        return compound;
    }

    @Override
    public void func_230337_a_(BlockState blockState, CompoundNBT compound)
    {
        super.func_230337_a_(blockState, compound);

        this.compressTimer = compound.func_74762_e("CompressTimer");
    }
}
