package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModProperties;
import ilja615.iljatech.power.IMechanicalPowerAccepter;
import ilja615.iljatech.power.IMechanicalPowerSender;
import ilja615.iljatech.power.MechanicalPower;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DirectionalBlock;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import org.spongepowered.asm.mixin.Interface;

import java.util.ArrayList;
import java.util.Random;

import net.minecraft.block.AbstractBlock.Properties;

public class GearboxBlock extends Block implements IMechanicalPowerAccepter, IMechanicalPowerSender
{
    public static final DirectionProperty FACING = DirectionalBlock.field_176387_N;

    public GearboxBlock(Properties properties)
    {
        super(properties);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.OFF));
    }

    @Override
    public void func_225534_a_(BlockState state, ServerWorld worldIn, BlockPos pos, Random rand)
    {
        super.func_225534_a_(state, worldIn, pos, rand);
        if (state.func_177230_c() != this) { return; }

        if (state.func_177229_b(ModProperties.MECHANICAL_POWER) == MechanicalPower.ALMOST_STOPPING)
        {
            worldIn.func_175656_a(pos, state.func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.OFF));
        }
        else if (state.func_177229_b(ModProperties.MECHANICAL_POWER) == MechanicalPower.SPINNING)
        {
            ArrayList<Direction> directions = new ArrayList<Direction>(); // Potential directions that power could be outputted to.
            for (Direction dir : Direction.values()) {
                if (dir != state.func_177229_b(FACING)) // A gearbox can not output to his "input" side.
                {
                    Block other = worldIn.func_180495_p(pos.func_177972_a(dir)).func_177230_c();
                    if (other instanceof IMechanicalPowerAccepter && ((IMechanicalPowerAccepter)other).acceptsPower(worldIn, pos.func_177972_a(dir), dir.func_176734_d()))
                        directions.add(dir);
                }
            }
            if (directions.size() > 0) {
                Direction randomlyPickedDirection = directions.get(rand.nextInt(directions.size()));
                sendPower(worldIn, pos, randomlyPickedDirection);
            } else {
                // There was nowhere to output to...
                worldIn.func_205220_G_().func_205360_a(pos, this, 5);
                worldIn.func_175656_a(pos, state.func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.ALMOST_STOPPING));
            }
        }
    }

    @Override
    public void receivePower(World world, BlockPos thisPos)
    {
        world.func_205220_G_().func_205360_a(thisPos, this, 10);
        IMechanicalPowerAccepter.super.receivePower(world, thisPos);
    }

    @Override
    public boolean acceptsPower(World world, BlockPos thisPos, Direction sideFrom)
    {
        BlockState state = world.func_180495_p(thisPos);
        return (state.func_235901_b_(FACING) && state.func_177229_b(FACING) == sideFrom && state.func_235901_b_(ModProperties.MECHANICAL_POWER) && state.func_177229_b(ModProperties.MECHANICAL_POWER) != MechanicalPower.SPINNING);
    }

    @Override
    public boolean sendPower(World world, BlockPos thisPos, Direction face)
    {
        BlockState state = world.func_180495_p(thisPos);
        if (IMechanicalPowerSender.super.sendPower(world, thisPos, face))
        {
            world.func_205220_G_().func_205360_a(thisPos, this, 5);
            world.func_175656_a(thisPos, state.func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.ALMOST_STOPPING));
            return true;
        } else {
            return false;
        }
    }

    public BlockState func_196258_a(BlockItemUseContext context)
    {
        return this.func_176223_P().func_206870_a(FACING, context.func_196010_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(ModProperties.MECHANICAL_POWER, FACING);
    }
}
