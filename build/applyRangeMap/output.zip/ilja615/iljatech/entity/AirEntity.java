package ilja615.iljatech.entity;

import ilja615.iljatech.blocks.StokedFireBlock;
import ilja615.iljatech.init.ModBlocks;
import ilja615.iljatech.init.ModParticles;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.particles.BasicParticleType;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.world.World;

public class AirEntity extends AbstractGasEntity
{
    public AirEntity(EntityType<? extends AbstractGasEntity> entityTypeIn, World worldIn)
    {
        super(entityTypeIn, worldIn);
    }

    @Override
    BasicParticleType getParticle()
    {
        return ParticleTypes.field_197598_I;
    }

    @Override
    int maxLifeTime()
    {
        return 120;
    }

    @Override
    protected void func_191955_a(BlockState state)
    {
        super.func_191955_a(state);
        if (this.field_70170_p.field_72995_K)
        {
            return;
        }
        if (state.func_177230_c() == Blocks.field_150480_ab)
        {
            if (field_70170_p.func_180495_p(this.func_233580_cy_()).func_177230_c() == Blocks.field_150480_ab)
                field_70170_p.func_180501_a(this.func_233580_cy_(), ModBlocks.STOKED_FIRE.get().func_176223_P(), 3);
        }
        else if (state.func_177230_c() == ModBlocks.STOKED_FIRE.get())
        {
            if (field_70170_p.func_180495_p(this.func_233580_cy_()).func_177230_c() == ModBlocks.STOKED_FIRE.get())
                field_70170_p.func_180501_a(this.func_233580_cy_(), ModBlocks.STOKED_FIRE.get().func_176223_P().func_206870_a(StokedFireBlock.AIR, 3), 3);
        }
    }
}
