package ilja615.iljatech.blocks;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import ilja615.iljatech.util.Edge;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFaceBlock;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import net.minecraft.block.AbstractBlock.Properties;

public class NailsBlock extends Block
{
    public static final DirectionProperty FACE = BlockStateProperties.field_208155_H;
    public static final IntegerProperty STAGE = IntegerProperty.func_177719_a("stage", 0, 3);

    protected static final VoxelShape UP_BIG_AABB = Block.func_208617_a(1.0D, 10.0D, 1.0D, 15.0D, 16.0D, 15.0D);
    protected static final VoxelShape DOWN_BIG_AABB = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 6.0D, 15.0D);
    protected static final VoxelShape NORTH_BIG_AABB = Block.func_208617_a(1.0D, 1.0D, 0.0D, 15.0D, 15.0D, 6.0D);
    protected static final VoxelShape SOUTH_BIG_AABB = Block.func_208617_a(1.0D, 1.0D, 10.0D, 15.0D, 15.0D, 16.0D);
    protected static final VoxelShape WEST_BIG_AABB = Block.func_208617_a(0.0D, 1.0D, 1.0D, 6.0D, 15.0D, 15.0D);
    protected static final VoxelShape EAST_BIG_AABB = Block.func_208617_a(10.0D, 1.0D, 1.0D, 16.0D, 15.0D, 15.0D);
    protected static final VoxelShape UP_SMALL_AABB = Block.func_208617_a(1.0D, 13.0D, 1.0D, 15.0D, 16.0D, 15.0D);
    protected static final VoxelShape DOWN_SMALL_AABB = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 3.0D, 15.0D);
    protected static final VoxelShape NORTH_SMALL_AABB = Block.func_208617_a(1.0D, 1.0D, 0.0D, 15.0D, 15.0D, 3.0D);
    protected static final VoxelShape SOUTH_SMALL_AABB = Block.func_208617_a(1.0D, 1.0D, 13.0D, 15.0D, 15.0D, 16.0D);
    protected static final VoxelShape WEST_SMALL_AABB = Block.func_208617_a(0.0D, 1.0D, 1.0D, 3.0D, 15.0D, 15.0D);
    protected static final VoxelShape EAST_SMALL_AABB = Block.func_208617_a(13.0D, 1.0D, 1.0D, 16.0D, 15.0D, 15.0D);

    public NailsBlock(Properties properties)
    {
        super(properties);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(STAGE, 0).func_206870_a(FACE, Direction.DOWN));
    }

    public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context)
    {
        if (state.func_177229_b(STAGE) == 0 || state.func_177229_b(STAGE) == 1)
        {
            switch((Direction)state.func_177229_b(FACE)) {
                case DOWN:
                default:
                    return DOWN_BIG_AABB;
                case UP:
                    return UP_BIG_AABB;
                case NORTH:
                    return NORTH_BIG_AABB;
                case SOUTH:
                    return SOUTH_BIG_AABB;
                case WEST:
                    return WEST_BIG_AABB;
                case EAST:
                    return EAST_BIG_AABB;
            }
        } else
        {
            switch((Direction)state.func_177229_b(FACE)) {
                case DOWN:
                default:
                    return DOWN_SMALL_AABB;
                case UP:
                    return UP_SMALL_AABB;
                case NORTH:
                    return NORTH_SMALL_AABB;
                case SOUTH:
                    return SOUTH_SMALL_AABB;
                case WEST:
                    return WEST_SMALL_AABB;
                case EAST:
                    return EAST_SMALL_AABB;
            }
        }
    }

    @Override
    public boolean func_196260_a(BlockState state, IWorldReader worldIn, BlockPos pos)
    {
        return HorizontalFaceBlock.func_220185_b(worldIn, pos, state.func_177229_b(FACE));
    }

    @Nullable
    public BlockState func_196258_a(BlockItemUseContext context)
    {
        return this.func_176223_P().func_206870_a(FACE, context.func_196000_l().func_176734_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(STAGE, FACE);
    }
}
