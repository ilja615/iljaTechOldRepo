package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModProperties;
import ilja615.iljatech.power.IMechanicalPowerSender;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFaceBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;

import net.minecraft.block.AbstractBlock.Properties;

public class CrankBlock extends Block implements IMechanicalPowerSender
{
    public static final DirectionProperty FACING = BlockStateProperties.field_208155_H;
    public static final IntegerProperty ROTATION = IntegerProperty.func_177719_a("rotation", 0, 15);

    public CrankBlock(Properties p_i48440_1_) {
        super(p_i48440_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(ROTATION, 0));
    }

    @Override
    public boolean func_196260_a(BlockState state, IWorldReader worldIn, BlockPos pos)
    {
        return HorizontalFaceBlock.func_220185_b(worldIn, pos, state.func_177229_b(FACING));
    }

    @Override
    public ActionResultType func_225533_a_(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockRayTraceResult rayTraceResult)
    {
        if (state.func_177230_c() == this)
        {
            sendPower(world, pos, state.func_177229_b(FACING));
            world.func_175656_a(pos, state.func_206870_a(ROTATION, (state.func_177229_b(ROTATION) + 1) % 16));
            return ActionResultType.SUCCESS;
        }
        return super.func_225533_a_(state, world, pos, player, hand, rayTraceResult);
    }

    public BlockState func_196258_a(BlockItemUseContext context)
    {
        return this.func_176223_P().func_206870_a(FACING, context.func_196000_l().func_176734_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(ROTATION, FACING);
    }
}
