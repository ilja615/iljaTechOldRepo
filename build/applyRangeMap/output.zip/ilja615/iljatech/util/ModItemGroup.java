package ilja615.iljatech.util;

import net.minecraft.block.Blocks;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class ModItemGroup extends ItemGroup
{
    public static final ModItemGroup instance = new ModItemGroup(ItemGroup.field_78032_a.length, "iljatech");

    private ModItemGroup(int index, String label)
    {
        super(index, label);
    }

    @Override
    public ItemStack func_78016_d()
    {
        return new ItemStack(Blocks.field_192434_dI);
    }
}
