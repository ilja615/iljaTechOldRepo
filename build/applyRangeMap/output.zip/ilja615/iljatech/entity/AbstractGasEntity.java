package ilja615.iljatech.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MoverType;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.IPacket;
import net.minecraft.particles.BasicParticleType;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.network.NetworkHooks;

public abstract class AbstractGasEntity extends Entity
{
    public AbstractGasEntity(EntityType<? extends AbstractGasEntity> entityTypeIn, World worldIn) {
        super(entityTypeIn, worldIn);
    }

    abstract BasicParticleType getParticle();
    abstract int maxLifeTime();

    @Override
    protected void func_70088_a() {

    }

    @Override
    protected void func_70037_a(CompoundNBT compound) {

    }

    @Override
    protected void func_213281_b(CompoundNBT compound) {

    }

    @Override
    public IPacket<?> func_213297_N() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public void func_70071_h_()
    {
        this.func_213315_a(MoverType.SELF, this.func_213322_ci());
        if (this.field_70170_p.field_72995_K)
        {
            if (field_70146_Z.nextFloat() < 0.25 - (((float)this.field_70173_aa) / 2000.0f)) this.field_70170_p.func_195594_a(this.getParticle(), this.func_226277_ct_() + r(), this.func_226278_cu_() + r(), this.func_226281_cx_() + r(), 0.0d, 0.0d, 0.0d);
        } else {
            if (this.field_70173_aa >= this.maxLifeTime()) {
                this.func_70106_y();
                return;
            }
            this.field_70169_q = this.func_226277_ct_();
            this.field_70167_r = this.func_226278_cu_();
            this.field_70166_s = this.func_226281_cx_();
            this.func_213317_d(this.func_213322_ci().func_216372_d(0.98D, 1.0D, 0.98D).func_72441_c(0.0d, this instanceof AirEntity ? 0.007d : 0.0d, 0.0d));
        }
    }

    private float r()
    {
        return field_70146_Z.nextFloat()*0.6f - 0.3f;
    }
}