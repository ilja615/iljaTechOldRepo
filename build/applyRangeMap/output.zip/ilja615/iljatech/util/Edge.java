package ilja615.iljatech.util;

import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.util.Direction;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.BlockPos;

public enum Edge implements IStringSerializable
{
    NORTHEAST("northeast"),
    NORTHWEST("northwest"),
    SOUTHEAST("southeast"),
    SOUTHWEST("southwest");

    private final String name;
    private Edge(String nameIn) {
        this.name = nameIn;
    }

    public static Edge getEdgeForContext(BlockItemUseContext context)
    {
        Edge edge = Edge.SOUTHEAST;
            if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() >= 0.5d && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() >= 0.5d)
                edge = Edge.SOUTHEAST;
            else if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() >= 0.5d && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() < 0.5d)
                edge = Edge.NORTHEAST;
            else if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() < 0.5d && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() >= 0.5d)
                edge = Edge.SOUTHWEST;
            else if (context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() < 0.5d && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() < 0.5d)
                edge = Edge.NORTHWEST;

        return edge;
    }

    @Override
    public String func_176610_l() { return this.name; }
}