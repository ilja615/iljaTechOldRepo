package ilja615.iljatech.containers;

import ilja615.iljatech.containers.other_stuff.MaxStackSize1Slot;
import ilja615.iljatech.init.ModBlocks;
import ilja615.iljatech.init.ModContainerTypes;
import ilja615.iljatech.tileentities.CrafterMachineTileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IWorldPosCallable;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

import java.util.Objects;

public class CrafterMachineContainer extends Container
{
    private final IWorldPosCallable canInteractWithCallable;
    private CrafterMachineTileEntity te;

    public CrafterMachineContainer(final int windowId, final PlayerInventory playerInventory, final CrafterMachineTileEntity tileEntity)
    {
        super(ModContainerTypes.CRAFTER_MACHINE.get(), windowId);
        this.canInteractWithCallable = IWorldPosCallable.func_221488_a(tileEntity.func_145831_w(), tileEntity.func_174877_v());
        this.te = tileEntity;

        // Main Inventory
        final int startX = 62;
        final int startY = 17;
        final int slotSizePlus2 = 18;
        for (int row = 0 ; row < 3 ; ++row)
        {
            for (int column = 0 ; column < 3 ; ++column)
            {
                int finalRow = row;
                int finalColumn = column;
                tileEntity.cmItemStackHandler.ifPresent(h -> this.func_75146_a(new MaxStackSize1Slot(h, finalRow * 3 + finalColumn, startX + (finalColumn * slotSizePlus2), startY + (finalRow * slotSizePlus2))));
            }
        }

        // HotBar
        final int hotBarStartY = 142;
        final int playerInvStartX = 8;
        for (int column = 0; column < 9; ++column)
        {
            this.func_75146_a(new Slot(playerInventory, column, playerInvStartX + (column * slotSizePlus2), hotBarStartY));
        }

        // Main Player Inventory
        final int playerInvStartY = 84;
        for (int row = 0; row < 3; row++)
        {
            for (int column = 0; column < 9; column++)
            {
                this.func_75146_a(new Slot(playerInventory, 9 + (row * 9) + column, playerInvStartX + (column * slotSizePlus2), playerInvStartY + (row * slotSizePlus2)));
            }
        }
    }

    private static CrafterMachineTileEntity getTileEntity(final PlayerInventory playerInventory, final PacketBuffer data)
    {
        Objects.requireNonNull(playerInventory, "playerInventory cannot be null");
        Objects.requireNonNull(data, "data cannot be null");
        final TileEntity tileAtPos = playerInventory.field_70458_d.field_70170_p.func_175625_s(data.func_179259_c());
        if (tileAtPos instanceof CrafterMachineTileEntity)
        {
            return (CrafterMachineTileEntity) tileAtPos;
        }
        throw new IllegalStateException("Tile entity is not correct! " + tileAtPos);
    }

    public CrafterMachineContainer(final int windowId, final PlayerInventory playerInventory, final PacketBuffer data)
    {
        this(windowId, playerInventory, getTileEntity(playerInventory, data));
    }

    @Override
    public boolean func_75145_c(PlayerEntity playerIn)
    {
        return func_216963_a(canInteractWithCallable, playerIn, ModBlocks.CRAFTER_MACHINE.get());
    }

    @Override
    public ItemStack func_82846_b(PlayerEntity playerIn, int index)
    {
        //this.inventorySlots.forEach(s -> { if (s.getHasStack()) System.out.println("Slot "+index+" : "+s.getStack()); else System.out.println("Slot "+index+" : "+"Empty Item Stack");});
        ItemStack itemStack = ItemStack.field_190927_a;
        final Slot slot = this.field_75151_b.get(index);
        if (slot != null && slot.func_75216_d())
        {
            final ItemStack itemStack1 = slot.func_75211_c();
            itemStack = itemStack1.func_77946_l();
            if (index < 9)
            {
                if (!this.func_75135_a(itemStack1, 9, this.field_75151_b.size(), true))
                {
                    return ItemStack.field_190927_a;
                }
            }
            else if (!this.func_75135_a(itemStack1, 0, 9, false))
            {
                return ItemStack.field_190927_a;
            }

            if (itemStack1.func_190926_b())
            {
                slot.func_75215_d(ItemStack.field_190927_a);
            }
            else
            {
                slot.func_75218_e();
            }
        }
        return itemStack;
    }
}
