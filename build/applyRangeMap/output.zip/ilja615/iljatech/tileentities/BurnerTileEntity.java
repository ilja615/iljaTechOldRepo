package ilja615.iljatech.tileentities;

import ilja615.iljatech.blocks.BurnerBlock;
import ilja615.iljatech.entity.AbstractGasEntity;
import ilja615.iljatech.entity.SteamEntity;
import ilja615.iljatech.init.ModEntities;
import ilja615.iljatech.init.ModTileEntityTypes;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CauldronBlock;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.ITickableTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.Direction;
import net.minecraft.util.NonNullList;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.wrapper.EmptyHandler;

import javax.annotation.Nonnull;

public class BurnerTileEntity extends TileEntity implements ITickableTileEntity
{
    public NonNullList<ItemStack> items = NonNullList.func_191197_a(1, ItemStack.field_190927_a);
    private final static EmptyHandler EMPTYHANDLER = new EmptyHandler();
    public LazyOptional<IItemHandlerModifiable> burnerItemStackHandler = LazyOptional.of(() -> new BurnerTileEntity.BurnerItemStackHandler(this));
    private int burnTime;

    public BurnerTileEntity(TileEntityType<?> tileEntityTypeIn) { super(tileEntityTypeIn); }
    public BurnerTileEntity() { this(ModTileEntityTypes.BURNER.get()); }

    public NonNullList<ItemStack> getItems() {
        return this.items;
    }

    public void setItems(NonNullList<ItemStack> items) {
        this.items = items;
    }

    @Override
    public void func_73660_a()
    {
        boolean flag = this.isBurning();
        boolean flag1 = false;
        if (this.isBurning()) {
            --this.burnTime;
            if (this.burnTime % 100 == 0)
            {
                this.emitHeat();
            }
        }
        if (!this.field_145850_b.field_72995_K) {
            ItemStack itemstack = this.items.get(0);
            if (!this.isBurning())
            {
                this.burnTime = getBurnTime(itemstack);
                if (this.isBurning())
                {
                    flag1 = true;
                    if (itemstack.hasContainerItem())
                        this.items.set(0, itemstack.getContainerItem());
                    else
                    if (!itemstack.func_190926_b()) {
                        Item item = itemstack.func_77973_b();
                        itemstack.func_190918_g(1);
                        if (itemstack.func_190926_b()) {
                            this.items.set(0, itemstack.getContainerItem());
                        }
                    }
                }
            }
            if (flag != this.isBurning()) {
                flag1 = true;
                this.field_145850_b.func_180501_a(this.field_174879_c, this.field_145850_b.func_180495_p(this.field_174879_c).func_206870_a(BurnerBlock.LIT, Boolean.valueOf(this.isBurning())), 3);
            }
        }
        if (flag1) {
            this.func_70296_d();
        }
    }

    private boolean isBurning() {
        return this.burnTime > 0;
    }

    @Override
    public CompoundNBT func_189515_b(CompoundNBT compound)
    {
        super.func_189515_b(compound);
        ItemStackHelper.func_191282_a(compound, this.items);
        compound.func_74768_a("BurnTime", this.burnTime);
        return compound;
    }

    @Override
    public void func_230337_a_(BlockState blockState, CompoundNBT compound)
    {
        super.func_230337_a_(blockState, compound);
        this.items = NonNullList.func_191197_a(this.items.size(), ItemStack.field_190927_a);
        ItemStackHelper.func_191283_b(compound, this.items);
        burnerItemStackHandler.ifPresent(h ->
        {
            for (int i = 0; i < h.getSlots(); i++)
            {
                h.setStackInSlot(i, items.get(i));
            }
        });
        this.burnTime = compound.func_74762_e("BurnTime");
    }

    @Override
    protected void invalidateCaps()
    {
        this.burnerItemStackHandler.invalidate();
        super.invalidateCaps();
    }

    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, Direction direction)
    {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return burnerItemStackHandler.cast();
        }
        return super.getCapability(capability, direction);
    }

    @Override
    public void func_145843_s() {
        super.func_145843_s();
        if (burnerItemStackHandler != null) {
            burnerItemStackHandler.invalidate();
        }
    }

    private void emitHeat()
    {
        if (!this.field_145850_b.field_72995_K) {
            BlockState state = this.field_145850_b.func_180495_p(this.field_174879_c.func_177984_a());
            if (this.field_174879_c.func_177956_o() < this.field_145850_b.func_217301_I() - 1 && state.func_177230_c() == Blocks.field_150383_bp) {
                int value = state.func_177229_b(CauldronBlock.field_176591_a) - 1; // The value that the cauldron level would be.
                if (value >= 0) {
                    this.field_145850_b.func_175656_a(this.field_174879_c.func_177984_a(), state.func_206870_a(CauldronBlock.field_176591_a, value));
                    AbstractGasEntity gasEntity = ModEntities.STEAM_CLOUD.get().func_200721_a(this.field_145850_b);
                    gasEntity.func_70012_b(this.field_174879_c.func_177958_n() + 0.5f, this.field_174879_c.func_177956_o() + 1.8f, this.field_174879_c.func_177952_p() + 0.5f, 0.0f, 0.0F);
                    gasEntity.func_213293_j(0.0d, 0.05d, 0.0d);
                    this.field_145850_b.func_217376_c(gasEntity);
                }
            }
        }
    }

    private class BurnerItemStackHandler extends ItemStackHandler implements IItemHandler
    {
        private final BurnerTileEntity tile;

        public BurnerItemStackHandler(BurnerTileEntity te)
        {
            super(1);
            tile = te;
        }

        @Override
        protected void onContentsChanged(int slot)
        {
            tile.items.set(slot, this.stacks.get(slot));
            tile.func_70296_d();
        }
    }

    protected int getBurnTime(ItemStack fuel) {
        if (fuel.func_190926_b()) {
            return 0;
        } else {
            Item item = fuel.func_77973_b();
            return ForgeHooks.getBurnTime(fuel);
        }
    }
}
