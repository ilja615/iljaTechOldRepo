package ilja615.iljatech.tileentities;

import ilja615.iljatech.blocks.BellowsBlock;
import ilja615.iljatech.init.ModBlocks;
import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.util.interactions.Wind;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.TickableBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

public class BellowsTileEntity extends BlockEntity implements TickableBlockEntity
{
    public BellowsTileEntity(BlockEntityType<?> tileEntityTypeIn) { super(tileEntityTypeIn); }
    public BellowsTileEntity() { this(ModTileEntityTypes.BELLOWS.get()); }
    private int compressTimer;

    @Override
    public void tick()
    {
        if (this.compressTimer > 0)
        {
            --this.compressTimer;
            BlockState oldState = this.level.getBlockState(worldPosition);
            if (this.compressTimer == 15)
            {
                this.level.setBlockAndUpdate(worldPosition, oldState.setValue(BellowsBlock.COMPRESSION, 2));
                Direction facing = level.getBlockState(worldPosition).getValue(DirectionalBlock.FACING);
                double d0 = (facing == Direction.EAST ? 0.6d : 0.0d) + (facing == Direction.WEST ? -0.6d : 0.0d);
                double d1 = (facing == Direction.UP ? 0.6d : 0.0d) + (facing == Direction.DOWN ? -0.6d : 0.0d);
                double d2 = (facing == Direction.NORTH ? -0.6d : 0.0d) + (facing == Direction.SOUTH ? 0.6d : 0.0d);
                Wind.addWind(level, this.getBlockPos(), facing, 8, 0.4f);
            }
            if (this.compressTimer == 10)
            {
                this.level.setBlockAndUpdate(worldPosition, oldState.setValue(BellowsBlock.COMPRESSION, 1));
            }
            if (this.compressTimer == 0)
            {
                this.level.setBlockAndUpdate(worldPosition, oldState.setValue(BellowsBlock.COMPRESSION, 0));
            }
        }
    }

    public void compress(Level world, BlockPos pos)
    {
        BlockState oldState = world.getBlockState(pos);
        if (oldState.getBlock() == ModBlocks.BELLOWS.get() && oldState.getValue(BellowsBlock.COMPRESSION) == 0)
        {
            world.setBlockAndUpdate(pos, oldState.setValue(BellowsBlock.COMPRESSION, 1));
            this.compressTimer = 20;
        }
    }

    @Override
    public CompoundTag save(CompoundTag compound)
    {
        super.save(compound);
        compound.putInt("CompressTimer", this.compressTimer);
        return compound;
    }

    @Override
    public void load(BlockState blockState, CompoundTag compound)
    {
        super.load(blockState, compound);

        this.compressTimer = compound.getInt("CompressTimer");
    }
}
