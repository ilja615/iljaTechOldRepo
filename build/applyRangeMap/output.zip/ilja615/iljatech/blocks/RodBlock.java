package ilja615.iljatech.blocks;

import com.google.common.collect.Maps;
import ilja615.iljatech.util.Edge;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SixWayBlock;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;

import javax.annotation.Nullable;
import java.util.Map;

public class RodBlock extends Block
{
    public static final BooleanProperty NORTHEAST = BooleanProperty.func_177716_a("northeast");
    public static final BooleanProperty NORTHWEST = BooleanProperty.func_177716_a("northwest");
    public static final BooleanProperty SOUTHEAST = BooleanProperty.func_177716_a("southeast");
    public static final BooleanProperty SOUTHWEST = BooleanProperty.func_177716_a("southwest");
    public static final BooleanProperty WATERLOGGED = BlockStateProperties.field_208198_y;

    public static final Map<Edge, BooleanProperty> EDGE_TO_PROPERTY_MAP = Util.func_200696_a(Maps.newEnumMap(Edge.class), (edgeBooleanPropertyEnumMap) -> {
        edgeBooleanPropertyEnumMap.put(Edge.NORTHEAST, NORTHEAST);
        edgeBooleanPropertyEnumMap.put(Edge.NORTHWEST, NORTHWEST);
        edgeBooleanPropertyEnumMap.put(Edge.SOUTHEAST, SOUTHEAST);
        edgeBooleanPropertyEnumMap.put(Edge.SOUTHWEST, SOUTHWEST);
    });

    private static final VoxelShape NORTHEAST_AABB = Block.func_208617_a(14.0D, 0.0D, 0.0D, 16.0D, 16.0D, 2.0D);
    private static final VoxelShape NORTHWEST_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 2.0D, 16.0D, 2.0D);
    private static final VoxelShape SOUTHEAST_AABB = Block.func_208617_a(14.0D, 0.0D, 14.0D, 16.0D, 16.0D, 16.0D);
    private static final VoxelShape SOUTHWEST_AABB = Block.func_208617_a(0.0D, 0.0D, 14.0D, 2.0D, 16.0D, 16.0D);

    public RodBlock(AbstractBlock.Properties properties)
    {
        super(properties);
        this.func_180632_j(this.field_176227_L.func_177621_b()
                .func_206870_a(NORTHEAST, Boolean.FALSE)
                .func_206870_a(NORTHWEST, Boolean.FALSE)
                .func_206870_a(SOUTHEAST, Boolean.FALSE)
                .func_206870_a(SOUTHWEST, Boolean.FALSE)
                .func_206870_a(WATERLOGGED, Boolean.FALSE));
    }

    public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
        VoxelShape voxelshape = VoxelShapes.func_197880_a();
        if (state.func_177229_b(NORTHEAST))     { voxelshape = VoxelShapes.func_197872_a(voxelshape, NORTHEAST_AABB); }
        if (state.func_177229_b(NORTHWEST))     { voxelshape = VoxelShapes.func_197872_a(voxelshape, NORTHWEST_AABB); }
        if (state.func_177229_b(SOUTHEAST))     { voxelshape = VoxelShapes.func_197872_a(voxelshape, SOUTHEAST_AABB); }
        if (state.func_177229_b(SOUTHWEST))     { voxelshape = VoxelShapes.func_197872_a(voxelshape, SOUTHWEST_AABB); }
        return voxelshape;
    }

    @Nullable
    public BlockState func_196258_a(BlockItemUseContext context)
    {
        BlockPos pos = context.func_195995_a();
        BlockState blockState = context.func_195991_k().func_180495_p(pos).func_203425_a(this) ? context.func_195991_k().func_180495_p(pos) : this.func_176223_P();
        return blockState.func_206870_a(EDGE_TO_PROPERTY_MAP.get(Edge.getEdgeForContext(context)), true);
    }

    public boolean func_196253_a(BlockState blockState, BlockItemUseContext context) {
        if (context.func_195996_i().func_77973_b() == this.func_199767_j()) {
            if (context.func_196000_l() == Direction.UP && context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() >= 1)
                return false;
            if (context.func_196000_l() == Direction.DOWN && context.func_221532_j().field_72448_b - context.func_195995_a().func_177956_o() <= 0)
                return false;
            if (context.func_196000_l() == Direction.EAST && context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() >= 1)
                return false;
            if (context.func_196000_l() == Direction.WEST && context.func_221532_j().field_72450_a - context.func_195995_a().func_177958_n() <= 0)
                return false;
            if (context.func_196000_l() == Direction.SOUTH && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() >= 1)
                return false;
            if (context.func_196000_l() == Direction.NORTH && context.func_221532_j().field_72449_c - context.func_195995_a().func_177952_p() <= 0)
                return false;
            return true;
        }
        return false;
    }

    // Watterlogging stuff

    @Override
    public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
        switch(p_196266_4_) {
            case LAND:
                return false;
            case WATER:
                return p_196266_2_.func_204610_c(p_196266_3_).func_206884_a(FluidTags.field_206959_a);
            case AIR:
                return false;
            default:
                return false;
        }
    }

    public FluidState func_204507_t(BlockState p_204507_1_) {
        return (Boolean)p_204507_1_.func_177229_b(WATERLOGGED) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
    }

    public boolean canContainFluid(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
        return true;
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder)
    {
        builder.func_206894_a(NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST, WATERLOGGED);
    }
}
