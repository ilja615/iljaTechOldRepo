package ilja615.iljatech.power;

import ilja615.iljatech.init.ModProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface IMechanicalPowerSender
{
    // The block will send power
    default boolean sendPower(World world, BlockPos thisPos, Direction face)
    {
        BlockPos neighborPos = thisPos.func_177972_a(face);
        if (world.func_180495_p(neighborPos).func_177230_c() instanceof IMechanicalPowerAccepter) {
            if (((IMechanicalPowerAccepter) world.func_180495_p(neighborPos).func_177230_c()).acceptsPower(world, neighborPos, face.func_176734_d())) {
                ((IMechanicalPowerAccepter) world.func_180495_p(neighborPos).func_177230_c()).receivePower(world, neighborPos);
                return true;
            }
        }
        return false;
    }
}