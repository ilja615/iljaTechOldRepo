package ilja615.iljatech.blocks;

import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.tileentities.BurnerTileEntity;
import ilja615.iljatech.tileentities.CrafterMachineTileEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.*;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.ItemTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.fml.network.NetworkHooks;

import javax.annotation.Nullable;

import net.minecraft.block.AbstractBlock.Properties;

public class BurnerBlock extends HorizontalBlock
{
    public static final DirectionProperty FACING = HorizontalBlock.field_185512_D;
    public static final IntegerProperty ASH_LEVEL = IntegerProperty.func_177719_a("ash_level", 0, 5);
    public static final BooleanProperty LIT = BlockStateProperties.field_208190_q;

    public BurnerBlock(Properties properties)
    {
        super(properties);
        this.func_180632_j((BlockState)((BlockState)this.field_176227_L.func_177621_b()).func_206870_a(FACING, Direction.NORTH).func_206870_a(LIT, false).func_206870_a(ASH_LEVEL, 0));
    }

    @Override
    public boolean hasTileEntity(BlockState state)
    {
        return true;
    }

    @Nullable
    @Override
    public TileEntity createTileEntity(BlockState state, IBlockReader world)
    {
        return ModTileEntityTypes.BURNER.get().func_200968_a();
    }

    @Override
    public void func_196243_a(BlockState state, World worldIn, BlockPos pos, BlockState newState, boolean isMoving)
    {
        if (state.func_177230_c() != newState.func_177230_c())
        {
            TileEntity tileEntity = worldIn.func_175625_s(pos);
            if (tileEntity instanceof BurnerTileEntity)
            {
                InventoryHelper.func_219961_a(worldIn, pos, ((BurnerTileEntity)tileEntity).getItems());
            }
        }
        super.func_196243_a(state, worldIn, pos, newState, isMoving);
    }

    @Override
    public boolean func_149740_M(BlockState blockState) {
        return true;
    }

    @Override
    public int func_180641_l(BlockState blockState, World worldIn, BlockPos pos)
    {
        if (blockState.func_235901_b_(ASH_LEVEL))
            return Math.min(blockState.func_177229_b(ASH_LEVEL), 15);
        else
            return 0;
    }

    public BlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return (BlockState)this.func_176223_P().func_206870_a(FACING, p_196258_1_.func_195992_f().func_176734_d());
    }

    @Override
    public ActionResultType func_225533_a_(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit)
    {
        ItemStack stack = player.func_184586_b(handIn);
        int burnTime = ForgeHooks.getBurnTime(stack);
        if (burnTime > 0 && !stack.hasContainerItem())
        {
            TileEntity tileEntity = worldIn.func_175625_s(pos);
            if (tileEntity instanceof BurnerTileEntity)
            {
                final ItemStack[] newStack = new ItemStack[]{stack};
                ((BurnerTileEntity)tileEntity).burnerItemStackHandler.ifPresent(h -> newStack[0] = h.insertItem(0, stack, false));
                player.func_184611_a(handIn, newStack[0]);
                return ActionResultType.SUCCESS;
            }
        }
        return super.func_225533_a_(state, worldIn, pos, player, handIn, hit);
    }

    protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) { p_206840_1_.func_206894_a(FACING, ASH_LEVEL, LIT); }
}
