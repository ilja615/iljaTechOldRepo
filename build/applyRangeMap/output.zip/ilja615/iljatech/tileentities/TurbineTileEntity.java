package ilja615.iljatech.tileentities;

import ilja615.iljatech.blocks.BellowsBlock;
import ilja615.iljatech.blocks.TurbineBlock;
import ilja615.iljatech.entity.AbstractGasEntity;
import ilja615.iljatech.init.ModBlocks;
import ilja615.iljatech.init.ModEntities;
import ilja615.iljatech.init.ModProperties;
import ilja615.iljatech.init.ModTileEntityTypes;
import ilja615.iljatech.power.IMechanicalPowerAccepter;
import ilja615.iljatech.power.MechanicalPower;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DirectionalBlock;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.ITickableTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;

public class TurbineTileEntity extends TileEntity implements ITickableTileEntity
{
    public TurbineTileEntity(TileEntityType<?> tileEntityTypeIn) { super(tileEntityTypeIn); }
    public TurbineTileEntity() { this(ModTileEntityTypes.TURBINE.get()); }
    private int amountTicks;

    @Override
    public void func_73660_a()
    {
        System.out.println(amountTicks);
        if (this.field_145850_b == null) return;
        if (this.field_145850_b.func_201670_d()) return;

        BlockState state = this.field_145850_b.func_180495_p(field_174879_c);
        if (state.func_177230_c() != ModBlocks.TURBINE.get().getBlock()) return;

        if (this.amountTicks > 0)
        {
            --this.amountTicks;

            // If it's on, then every tick, the turbine will attempt output power to a neighbour
            ArrayList<Direction> directions = new ArrayList<Direction>(); // Potential directions that power could be outputted to.
            for (Direction dir : Direction.values()) {
                if (dir != state.func_177229_b(DirectionalBlock.field_176387_N)) // A turbine can not output to his "input" side.
                {
                    Block other = this.field_145850_b.func_180495_p(field_174879_c.func_177972_a(dir)).func_177230_c();
                    if (other instanceof IMechanicalPowerAccepter && ((IMechanicalPowerAccepter)other).acceptsPower(this.field_145850_b, field_174879_c.func_177972_a(dir), dir.func_176734_d()))
                        directions.add(dir);
                }
            }
            if (directions.size() > 0) {
                Direction randomlyPickedDirection = directions.get(this.field_145850_b.field_73012_v.nextInt(directions.size()));
                ((TurbineBlock)state.func_177230_c()).sendPower(this.field_145850_b, field_174879_c, randomlyPickedDirection);
            }
        }

        // The code for correctly updating the blockState of the TurbineBlock
        state = this.field_145850_b.func_180495_p(field_174879_c); // Idk if this is needed a 2nd time but just in case for if it was changed in the meanwhile
        if (this.amountTicks > 5 && state.func_177229_b(ModProperties.MECHANICAL_POWER) != MechanicalPower.SPINNING)
        {
            this.field_145850_b.func_175656_a(field_174879_c, state.func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.SPINNING));
            System.out.println("started spinning");
        }
        else if (this.amountTicks == 5 && state.func_177229_b(ModProperties.MECHANICAL_POWER) != MechanicalPower.ALMOST_STOPPING)
        {
            this.field_145850_b.func_175656_a(field_174879_c, state.func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.ALMOST_STOPPING));
            System.out.println("almost stopping spinning");
        }
        else if (this.amountTicks <= 0 && state.func_177229_b(ModProperties.MECHANICAL_POWER) != MechanicalPower.OFF)
        {
            this.field_145850_b.func_175656_a(field_174879_c, state.func_206870_a(ModProperties.MECHANICAL_POWER, MechanicalPower.OFF));
            System.out.println("stopped spinning");
        }
    }

    public void startSpinning(World world, BlockPos pos, int amountTicksTime)
    {
        this.amountTicks = amountTicksTime;
    }

    @Override
    public CompoundNBT func_189515_b(CompoundNBT compound)
    {
        super.func_189515_b(compound);
        compound.func_74768_a("amountTicks", this.amountTicks);
        return compound;
    }

    @Override
    public void func_230337_a_(BlockState blockState, CompoundNBT compound)
    {
        super.func_230337_a_(blockState, compound);

        this.amountTicks = compound.func_74762_e("amountTicks");
    }
}
