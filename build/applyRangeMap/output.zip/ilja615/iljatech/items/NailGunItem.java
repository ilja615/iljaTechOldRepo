package ilja615.iljatech.items;

import net.minecraft.world.item.Item;

import net.minecraft.world.item.Item.Properties;

public class NailGunItem extends Item
{
    public NailGunItem(Properties properties)
    {
        super(properties);
    }


}
