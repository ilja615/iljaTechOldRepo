package ilja615.iljatech.items;

import net.minecraft.item.Item;

import net.minecraft.item.Item.Properties;

public class NailGunItem extends Item
{
    public NailGunItem(Properties properties)
    {
        super(properties);
    }


}
